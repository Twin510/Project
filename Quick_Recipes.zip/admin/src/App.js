import Header from './components/header';
import Viewrecipe from './components/viewrecipe';
import Addrecipe from './components/addrecipe';
import RecipeForm from './components/form';
import Addcategory from './components/addcategory';
import Viewcategory from './components/viewcategory';
import Login from './components/login';
import Forgotpass from './components/forgotpass';
import Viewuser from './components/viewuser';
import Viewsubscription from './components/viewsubscription';
import Viewfeedback from './components/viewfeedback';
import Userdetail from './components/userdetail';
import Report from './components/report';


import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Routes, Route} from "react-router-dom";
import Dash from './components/dash';



function App() {
  return (
    
    <div>
    {
      sessionStorage.getItem('admindata') == null ?
      <>
      <Router>
    
   
      <Routes>
      <Route  exact path='/' element={<Login/>}/>
        <Route  exact path='/forgot' element={<Forgotpass/>}/>
        </Routes>
        </Router>
        
     


      </>
      :
    
    <>
   
    <Router>
      <Header/>
   
      <Routes>
        
        <Route  exact path='/' element={<Dash/>}/>
        <Route  exact path='/addrecipe' element={<Addrecipe/>}/>
        <Route  exact path='/recipeform' element={<RecipeForm/>}/>
        <Route  exact path='/viewrecipe' element={<Viewrecipe/>}/>
        <Route  exact path='/addcategory' element={<Addcategory/>}/>
        <Route  exact path='/viewcategory' element={<Viewcategory/>}/>
        <Route  exact path='/login' element={<Login/>}/>
         <Route  exact path='/forgotpass' element={<Forgotpass/>}/> 
         <Route  exact path='/viewuser' element={<Viewuser/>}/>
         <Route  exact path='/viewsubscription' element={<Viewsubscription/>}/>
         <Route  exact path='/viewfeedback' element={<Viewfeedback/>}/>
         <Route  exact path='/userdetail' element={<Userdetail/>}/>
         <Route  exact path='/report' element={<Report/>}/>
        </Routes>
</Router>
</>
}
    </div>
  );
}

export default App;
