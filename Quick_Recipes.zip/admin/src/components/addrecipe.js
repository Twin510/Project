import React, {useState,useEffect} from "react";
import Axios from "axios";
function Addrecipe(){
const [filename,setfilename]=useState("");
const[catname,drop]=useState("");
const[cat,catlist]=useState([]);


useEffect(()=>{
    Axios.get('http://localhost:1334/api/getcategory',).then((response)=>{
   // alert(response.data);
    catlist(response.data);
    })
    
},[]);

    function subaddrecipe(){
        var rname=document.getElementById("rname").value;
        
        var cname=document.getElementById("cname").value;
        var rprice=document.getElementById("rprice").value;                                       
        //alert(rprice);
        //var rimage=document.getElementById("rimage").value;
        //alert(pnumber);
        var rdescription=document.getElementById("rdescription").value;
        //alert(address);
        var ringredients=document.getElementById("ringredients").value;
        //alert(dob);
        var wprice=document.getElementById("wprice").value;
       
        var mprice=document.getElementById("mprice").value;
       
        var yprice=document.getElementById("yprice").value;
       
        

        
        
            let formData = new FormData();

            formData.append("Rname",rname);
            formData.append("Cname",cname);
            formData.append("Rprice",rprice);
            formData.append("Rimage",filename);
            formData.append("Rdescription",rdescription);
            formData.append("Ringredients",ringredients);
            formData.append("Wprice",wprice);
            formData.append("Mprice",mprice);
            formData.append("Yprice",yprice);
            formData.append("catname",catname);
        

        Axios.post("http://localhost:1334/api/addrecipe",formData,{
            headers:{"Content-Type":"multipart/form-data"}
           
        
        }).then((response)=>{
        
        alert(response.data.msg);
        window.location="/";
        
        });
        
        }
        
    
    return(

        <>
 <section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
<div style={{marginRight:-490}}>
                 <h2 >MANAGE RECIPE</h2> 
                 </div>
                    
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">
          
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="header">
                           
                            <ul class="header-dropdown">
                                <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="zmdi zmdi-more"></i> </a>
                                    <ul class="dropdown-menu dropdown-menu-right">
                                        <li><a href="javascript:void(0);">Action</a></li>
                                        <li><a href="javascript:void(0);">Another action</a></li>
                                        <li><a href="javascript:void(0);">Something else</a></li>
                                    </ul>
                                </li>
                                <li class="remove">
                                    <a role="button" class="boxs-close"><i class="zmdi zmdi-close"></i></a>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <form >
                            <div class="form-group form-float">
                                <div class="row clearfix">
                                <div class="col-lg-5 col-md-6">
                                   <label><b>Recipe Name</b></label>
                                   <div class="input-group masked-input">
                                        <div class="input-group-prepend"></div>
                                    <input type="text" class="form-control" placeholder="Recipe Name"  required id="rname"/>
                                    </div>
                                    </div>
                                    <div class="col-lg-5 col-md-6">
                                <label><b>Category</b></label>
                                     <select onChange={(e)=>{drop(e.target.value)}} name="cat" id="cname"   class="form-control show-tick ms select2" data-placeholder="Select">
                                    {cat.map((val,index)=>{
                                        return(
                                            <>
                                            <option key={index} value={val.cat_name}>{val.cat_name}</option>
                                            </>
                                        )
                                    })}
                                    </select>
                                    </div>
                                  
                                  
                                </div>
                                </div>
                                
                                <div class="form-group form-float">
                                <div class="form-group form-float">
                                <label ><b>Recipe price</b></label>
                                    <input type="text" cols="30" rows="5" placeholder="Price" class="form-control no-resize" id="rprice"></input>
                                </div>
                                   
                                    
                                </div>
                                <div class="form-group form-float">
                                <div class="row clearfix">
                                <div class="col-lg-4 col-md-6">
                                    <label>Weekly Price</label>
                                    <div class="input-group masked-input">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-money"></i></span>
                                        </div>
                                        <input type="text" class="form-control date"  id="wprice" />
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label>Monthly price</label>
                                    <div class="input-group masked-input mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-money"></i></span>
                                        </div>
                                        <input type="text" class="form-control time24"id="mprice" />
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label>Yearly Price</label>
                                    <div class="input-group masked-input mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-money"></i></span>
                                        </div>
                                        <input type="text" class="form-control time12" id="yprice" />
                                    </div>
                                </div>
                                </div>
                                </div>
                                <div class="form-group form-float">
                                <label ><b>Recipe Image</b></label>
                                    <input type="file" class="form-control" placeholder="Recipe Image" name="recipe image" required onChange={(e)=>setfilename(e.target.files[0])}/>
                                </div>
                                <div class="form-group">
                                                                  
                                    
                                </div>
                                <div class="form-group form-float">
                                <label ><b>Description</b></label>
                                    <textarea name="Recipe description" cols="30" rows="5" placeholder="Description" class="form-control no-resize" required id="rdescription"></textarea>
                                </div>
                                <div class="form-group form-float">
                                <label ><b>Ingredients</b></label>
                                    <textarea name="Recipe ingredients" class="form-control no-resize" cols="30" rows="5" placeholder="Ingredients" required id="ringredients"></textarea>
                                </div>
                                <div class="form-group">
                                    <div class="checkbox">
                                        <input id="checkbox" type="checkbox"/>
                                        <label for="checkbox">I have read and accept the terms</label>
                                    </div>
                                </div>
                                <button class="btn btn-raised btn-primary waves-effect" type="button" onClick={subaddrecipe}>SUBMIT</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


          
        </div>
    </div>
</section>

        </>
    )
}export default Addrecipe