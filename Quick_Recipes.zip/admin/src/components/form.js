import React, { useState } from 'react';

function RecipeForm() {
  const [recipe, setRecipe] = useState({
    name: '',
    ingredients: '',
    instructions: '',
    prepTime: '',
    cookTime: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setRecipe(prevRecipe => ({ ...prevRecipe, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
    console.log(recipe);
  };

  return (
    <div className="container">
      <h2>Recipe Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="recipe-name">Recipe Name</label>
          <input type="text" id="recipe-name" name="name" value={recipe.name} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="ingredients">Ingredients</label>
          <textarea id="ingredients" name="ingredients" value={recipe.ingredients} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="instructions">Instructions</label>
          <textarea id="instructions" name="instructions" value={recipe.instructions} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="prep-time">Preparation Time</label>
          <input type="text" id="prep-time" name="prepTime" value={recipe.prepTime} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="cook-time">Cooking Time</label>
          <input type="text" id="cook-time" name="cookTime" value={recipe.cookTime} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <input type="submit" value="Submit" />
        </div>
      </form>
    </div>
  );
}

export default RecipeForm;