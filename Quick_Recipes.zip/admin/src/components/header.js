import React from "react";

function Header(){
    function logout(){
        sessionStorage.clear()
        window.location="/"
    }
	
    return(
<div>
<aside id="leftsidebar" class="sidebar">
    <div class="navbar-brand">
        <button class="btn-menu ls-toggle-btn" type="button"><i class="zmdi zmdi-menu"></i></button>
        <a href="index.html"><img src="assets/images/logo.svg" width="25" alt="Aero"/><span class="m-l-10">Aero</span></a>
    </div>
    <div class="menu">
        <ul class="list">
            <li>
                <div class="user-info">
                    <a class="image" href="profile.html"><img src="assets/images/profile_av.jpg" alt="User"/></a>
                    <div class="detail">
                        <h4>QUICK</h4>
                        <small>Super Admin</small>                        
                    </div>
                </div>
            </li>
            <li class="active open"><a href="/dash"><i class="zmdi zmdi-home"></i><span>Dashboard</span></a></li>
            <li><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-apps"></i><span>Manage Recipe</span></a>
                <ul class="ml-menu">
                    <li><a href="/addrecipe">Add Recipe</a></li>
                    <li><a href="/viewrecipe">View Recipe</a></li>
                                    
                </ul>
            </li>
            <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-assignment"></i><span>Manage Category</span></a>
                <ul class="ml-menu">
                    <li><a href="Addcategory">Add Category</a></li>
                    <li><a href="Viewcategory">View Category</a></li>
                   
                </ul>
            </li>
             <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-folder"></i><span>Manage User</span></a>
                <ul class="ml-menu">
                    <li><a href="viewuser">View User</a></li>
                 
                </ul>
            </li>
            <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-blogger"></i><span>Manage Feedback</span></a>
                <ul class="ml-menu">
                    <li><a href="viewfeedback">View Feedback</a></li>
                  
                </ul>
            </li>
            <li><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-shopping-cart"></i><span>Manage Subscription</span></a>
                <ul class="ml-menu">
                    <li><a href="viewsubscription">View Subscription</a></li>
                  
                </ul>
            </li>
            <li><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-shopping-cart"></i><span>Report</span></a>
                <ul class="ml-menu">
                    <li><a href="report">Revenue</a></li>
                  
                </ul>
            </li>
            
             
            < button class="btn btn-primary btn-block waves-effect waves-light" type="button" onClick={logout}>LOGOUT</button>
        </ul>
    </div>
</aside>
</div>
)
}export default Header;