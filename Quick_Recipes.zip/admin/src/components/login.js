import React from "react";
import Axios from "axios";
import "./login.css"
import Forgotpass from "./forgotpass";
import { useForm } from 'react-hook-form';


function Login(){
	const { register, handleSubmit, formState: { errors } } = useForm();
	function sublogin(data,e){
		console.log(data)
   e.preventDefault()
		
		var ename=document.getElementById("ename").value;
		//alert(ename);
		var pname=document.getElementById("pname").value;
		
		
	Axios.post("http://localhost:1334/api/adminlogin",{
	Ename:ename,Pname:pname

}).then((response)=>{
if(response.data.msg){
alert(response.data.msg);

window.location="/";
}
else{
	//alert("login successfully")
	let obj= {name:response.data[0]. a_email, a_password: response.data[0].
		a_password,Id:response.data[0].a_id}
		sessionStorage.setItem('admindata',JSON.stringify(obj));
		
		window.location="/";
}
});}

	
    return(

        <>


<div class="authentication">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-12">
                <form class="card auth_form">
                    <div class="header">
                        <img class="logo" src="assets/images/logo.svg" alt=""/>
                        <h5>Log in</h5>
                    </div>
                    <div class="body">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Email" required id="ename" {...register("ename", { required: "Email is mandatory",pattern:{value:/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,message:"Please enter valid Email"} })}/>
                            
							<div class="input-group-append">
                                <span class="input-group-text"><i class="zmdi zmdi-email"></i></span>
                            </div>
                        </div>
						<span className="error">{errors.ename?.message}</span> 

						<div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Password" required id="pname" {...register("pname", { required: "Password is mandatory",pattern:{value:/^(?=.*[A-Z][a-z])(?=.*[!@#$%^&*])(?=.{8,})/,message:"Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"} })}/>
							
						    <div class="input-group-append">                                
                                <span class="input-group-text"><i class="zmdi zmdi-lock"></i></span>
                            </div>   
						</div>
						<span className="error">{errors.pname?.message}</span>  
                       
                        <div class="checkbox">
                            <input id="remember_me" type="checkbox"/>
                            <label for="remember_me">Remember Me</label>
                        </div>
						<div class="signin_with mt-3">
                            <a class="link" href="/forgot" onClick={Forgotpass} >Forgot Password</a>
                        </div>
                        <button class="btn btn-primary btn-block waves-effect waves-light" type="button" onClick={handleSubmit(sublogin)}>LOGIN</button>                        
                        <div class="signin_with mt-3">
                            <p class="mb-0">or Sign Up using</p>
                            <button class="btn btn-primary btn-icon btn-icon-mini btn-round facebook"><i class="zmdi zmdi-facebook"></i></button>
                            <button class="btn btn-primary btn-icon btn-icon-mini btn-round twitter"><i class="zmdi zmdi-twitter"></i></button>
                            <button class="btn btn-primary btn-icon btn-icon-mini btn-round google"><i class="zmdi zmdi-google-plus"></i></button>
                        </div>
                    </div>
                </form>
                <div class="copyright text-center">
                    &copy;
                    <script>document.write(new Date().getFullYear())</script>,
                    <span><a href="templatespoint.net">Templates Point</a></span>
                </div>
            </div>
            <div class="col-lg-8 col-sm-12">
                <div class="card">
                    <img src="assets/images/signin.svg" alt="Sign In"/>
                </div>
            </div>
        </div>
    </div>
</div>

	
   

</>

);

}

export default Login;
