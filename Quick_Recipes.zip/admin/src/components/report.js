import React, {useState ,useEffect} from "react";
import Axios from "axios";
import { Link } from "react-router-dom";

function Report(){ 
    const [view1,setview1]=useState([]);
    const [modalID,setModalID]=useState(null);
    const [username,setusername]=useState()

    function subreport(){
        alert()
        var start_date=document.getElementById("fisrtdate").value;
   
        var end_date=document.getElementById("seconddate").value;
        

         
    {

        Axios.post('http://localhost:1334/api/report',{start_date:start_date,end_date:end_date}).then((response)=>{
            setusername( response.data)
            
       // alert(response.data);
        setview1(response.data);
        })
        
   
    }
    
        
        };
    
	//  const [view,setview]=useState([]);
                 
        
      return(
<>
    <section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div  class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2>Revenue</h2>
                    
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>
        <form >
        <table class="table table-striped m-b-0">
        <tr>
            
        <div class="form-group form-float">
        
            <th>
      
        <div class="agileits_reservation_grid">
									<div class="span1_of_1">
										<label><th>START DATE : </th></label> 
                                        <div class="input-group masked-input">
                                        <div class="input-group-prepend"></div>
										<div class="book_date"> 
											<i class="fa fa-calendar" aria-hidden="true"></i>
												<input  id="fisrtdate" name="Text" type="date"  required ="start_date"/>
                                                </div>

										</div>					
									</div>
									</div>
									 
									<div class="clearfix"></div>
								
                                </th>
                                <th>
                                
                                <div class="agileits_reservation_grid">
									<div class="span1_of_1">
										<label><th>END DATE : </th></label> 
										<div class="book_date"> 
											<i class="fa fa-calendar" aria-hidden="true"></i>
												<input  id="seconddate" name="Text" type="date"  required ="end_date"/>

										</div>	
                                        </div>				
									</div>
                                    
                                    </th>
                                    <td>  
                                                
                                     </td>
									 
									<div class="clearfix"></div>
								
                                </div>
                                </tr>
                                </table>
                                </form>
                              <div class="card-body">
                              <center>  
        
        <button class="btn btn-raised btn-primary waves-effect" onClick={subreport} >Submit</button></center>
      </div>
      <div class="container-fluid">
            
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-striped m-b-0">
                                    <thead>
                                        
                                            <tr>
                                            <th data-breakpoints="xs">Recipe Name</th>
                                            <th data-breakpoints="xs">Date</th> 
                                            <th data-breakpoints="xs">Recipe Plan</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                    {view1.map((val)=>{ 
                                    const isoDate = new Date(val.p_date);
                                    const day = isoDate.getDate().toString().padStart(2);
                                    const month = (isoDate.getMonth() + 1).toString().padStart(2, );
                                    const year = isoDate.getFullYear().toString().slice(); // Extract the last two digits of the year
                                    const formattedDate = `${day}-${month}-${year}`;
                                           

                                     return(
                                       
                                        <tr>
                                           <td>{val.rec_name}</td> 
                                           <td>{formattedDate}</td>
                                            <td>{val.pt}</td>
                                            
                                            
                                              
                                        </tr>
                                        ) })

                                       }
                                        
                                    </tbody>
                                       
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                               

        {/* <div class="container-fluid">
            
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-striped m-b-0">
                                    <thead>
                                        
                                            <tr>
                                            <th data-breakpoints="xs">User Name</th>
                                            <th data-breakpoints="xs">No of Recipe</th>
                                            <th data-breakpoints="xs">Action</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                   
                                       {view1.map((val)=>{ 
                                           

                                     return(
                                       
                                        <tr>
                                           <td>{val.f_name}</td> 
                                          
                                            <td>{val.rec_count}</td>  
                                            <td>  
                                                
                                                <Link to='/userdetail' state={{f_id:val.f_id}} >View more details</Link> 
                                               
                                               
                                               </td>
                                            
                                              
                                        </tr>
                                        ) })

                                       }
                                        
                                    </tbody>
                                       
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> */}
    </div>
</section>

</>
)
}export default Report