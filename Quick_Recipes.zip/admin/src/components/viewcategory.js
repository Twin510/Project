import React, {useState} from "react";
import Axios from "axios";
import { useEffect } from "react";  
import axios from "axios";
function Viewcategory(){  
    const [view1,setview1]=useState([]);
    const [modalID,setModalID]=useState(null);
    {
        useEffect(()=>{
        Axios.get('http://localhost:1334/api/getcategory',).then((response)=>{
       // alert(response.data);
        setview1(response.data);
        })
        
    },[]);
    
        
        };

  function delid(id){
   // e.preventDefault();
  alert(id);
  setModalID(id);
  }
        

      function delprod (id){
       
        Axios.post("http://localhost:1334/api/delcat",{
            mid:id
        
        }).then((response)=>{
        
        alert(response.data.msg);
       window.location="/";
        
        });
            
           
        }
      return(
<>
    <section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2>View Category</h2>
                    
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">
            
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-striped m-b-0">
                                    <thead>
                                        <tr>
                                            <th>Category Name</th>
                                             <th data-breakpoints="xs">Action</th> 
                                            
                                            
                                        </tr>
                                    </thead>
                                        <tbody>
                                       {view1.map((val)=>{ return(
                                       
                                        <tr>
                                            <td>{val.cat_name}</td>
                                            
                                            
                                            <td>  <button class="btn btn-primary btn-sm" ><i class="zmdi zmdi-edit"></i></button>
                                            <button class="btn btn-danger btn-sm" data-target="#exampleModalCenter" data-toggle="modal"  onClick={(e)=>delid(val.cat_id)}><i class="zmdi zmdi-delete"></i></button></td>
                                            
                                        </tr>
                                        ) })

                                       }
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header text-center">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                        <h1> Are  You sure want To DELETE</h1>
                       
                            <h1>{modalID}</h1>
                               <button type="button " onClick={(e)=> delprod(modalID)} style={{width:"60px",height:"40px",backgroundColor:"royalblue",color:"white" }} >Yes</button>
                               &nbsp;&nbsp;&nbsp;
                               &nbsp;
                               <button type="button " data-dismiss="modal"style={{width:"60px",height:"40px",backgroundColor:"red",color:"white" }}>NO</button>
                         
                        </div>

                    </div>
                </div>
            </div>
</>
)
}export default Viewcategory