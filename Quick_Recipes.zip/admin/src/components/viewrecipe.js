import React, {useState} from "react";
import Axios from "axios";
import { useEffect } from "react";  
import axios from "axios";
function Viewrecipe(){  
    const [view1,setview1]=useState([]);
    const [view,setview]=useState([]);
    const [modalID,setModalID]=useState(null);
    {
        useEffect(()=>{
        Axios.get('http://localhost:1334/api/getrecipe',).then((response)=>{
       // alert(response.data);
        setview1(response.data);
        })

        
    },[]);
    
        
        };

  function delid(id){
   // e.preventDefault();
  alert(id);
  setModalID(id);
  }

      
  function closemodel(){
     
    window.location.reload()
}


  function edit(mid){
 
      axios.post("http://localhost:1334/api/editrec",{mid:mid}).then((response)=>{
        setview(response.data);  
    
    })
    

  };
      
  
function save(m_id){
    alert(m_id)
    var rname=document.getElementById("rname").value;
    var rprice=document.getElementById("rprice").value;
    var wprice=document.getElementById("wprice").value;
    var mprice=document.getElementById("mprice").value;
    var yprice=document.getElementById("yprice").value;
    var ringredients=document.getElementById("ringredients").value;
    var rdescription=document.getElementById("rdescription").value;
    Axios.post("http://localhost:1334/api/edit",{

    Rname:rname,Rprice:rprice,Wprice:wprice,Mprice:mprice,Yprice:yprice,Ringredients:ringredients,Rdescription:rdescription,m_id:m_id
    }).then((response)=>{
        
        alert(response.data.msg);
       window.location="/";
        
        });
         
    
    }
    

  
    
    



      function delprod (id){
       
        Axios.post("http://localhost:1334/api/delrec",{
            mid:id
        
        }).then((response)=>{
        
        alert(response.data.msg);
       window.location="/";
        
        });
            
           
        }
      return(
<>
    <section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2>View Recipe</h2>
                    
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">
            
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-striped m-b-0">
                                    <thead>
                                        <tr>
                                            <th>Recipe Name</th>
                                            <th data-breakpoints="xs">Category</th>
                                            <th data-breakpoints="xs">Recipe Price</th>
                                            <th data-breakpoints="xs">Weekly price</th>
                                            <th data-breakpoints="xs">Monthly price</th>
                                            <th data-breakpoints="xs">Yearly price</th>
                                            {/* <th data-breakpoints="xs">Recipe Description</th>
                                            <th data-breakpoints="xs">Recipe Ingredients</th> */}
                                            <th>Recipe Image</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                        <tbody>
                                       {view1.map((val)=>{ return(
                                       
                                        <tr>
                                            <td>{val.rec_name}</td>
                                            <td>{val.choose_category}</td>
                                            <td>{val.rec_price}</td>
                                            <td>{val.w_price}</td>
                                            <td>{val.m_price}</td>
                                            <td>{val.y_price}</td>
                                            {/* <td>{val.rec_description}</td>
                                            <td>{val.rec_ingredients}</td> */}
                                            <td><span class="tag tag-danger"> </span><img src={"http://localhost:1334/public/"+val.rec_image } style={{width:"100px",height:"100px"}} />
                                            </td>

                                            <td>
                                            <button class="btn btn-primary btn-sm"  data-target="#myModal" data-toggle="modal"   onClick={(e)=>edit(val.m_id)}><i class="zmdi zmdi-edit"></i></button>
                                            <button class="btn btn-danger btn-sm" data-target="#exampleModalCenter" data-toggle="modal"  onClick={(e)=>delid(val.m_id)}><i class="zmdi zmdi-delete"></i></button>
                                                
                                                
                                                </td>
                                            
                                        </tr>
                                        ) })

                                       }
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header text-center">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                        <h1> Are  You sure want To DELETE</h1>
                       
                            <h1>{modalID}</h1>
                               <button type="button " onClick={(e)=> delprod(modalID)} style={{width:"60px",height:"40px",backgroundColor:"royalblue",color:"white" }} >Yes</button>
                               &nbsp;&nbsp;&nbsp;
                               &nbsp;
                               <button type="button " onClick={closemodel} data-dismiss="modal"style={{width:"60px",height:"40px",backgroundColor:"red",color:"white" }}>NO</button>
                         
                        </div>

                    </div>
                </div>
            </div>
            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header text-center">
                            <button type="button"   onClick={closemodel} class="close" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
            <div class="modal-body">
                
                {view.map((val1) => {

                  return (
                    <>
                    
                    <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Recipe Detail</h4>
                                    
                                    <div class="basic-form">
                                    <input type="text" value={val1.m_id} id="yyy" hidden />
                                            
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label>Recipe Name:</label>
                                                    <input type="text" defaultValue={val1.rec_name} class="form-control" id="rname" />
                                                </div>
                                           
                                            
                                                <div class="form-group col-md-6">
                                                    <label>Recipe Price:</label>
                                                    <input type="text" defaultValue={val1.rec_price} class="form-control" id="rprice" />
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label>Weekly Price:</label>
                                                    <input type="text" defaultValue={val1.w_price} class="form-control" id="wprice" />
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label>Monthly Price:</label>
                                                    <input type="text" defaultValue={val1.m_price} class="form-control" id="mprice" />
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label>Yearly Price:</label>
                                                    <input type="text" defaultValue={val1.y_price} class="form-control" id="yprice" />
                                                </div>
                                            </div>
                                            <div class="form-row">
                                             
                                                <div class="form-group col-md-6">
                                                    <label>Ingredients:</label>
                                                    <textarea defaultValue={val1.rec_ingredients} class="form-control" id="ringredients" />
                                                </div>
                                            </div>
                                            <div class="form-row">
                                             
                                                <div class="form-group col-md-6">
                                                    <label>Description:</label>
                                                    <textarea defaultValue={val1.rec_description} class="form-control" id="rdescription" />
                                                </div>
                                            </div> 
                                            {/* <div class="form-group col-md-6">
                                                <label>Post Category:</label>
                                                <select  name="orderby" class="form-control" onChange={(e) => {drop(e.target.value) }}>
                        {cat.map((val,index) => {
                            return (
                                <>
                              
                                    <option key={index} value={val.id}>{val.pc_name}</option>
                                </>
                            )
                        })}

                    </select>

                                            </div> */}
                                           
                                            {/* <div class="form-group">
                                                <label>Post Image:</label>
                                                <img  src={"http://localhost:4040/public/"+val1.p_img } style={{height:"80px",width:"150px"}}/>
                                                <input type="file"  onChange={(e) =>ptimg(e.target.files[0])} placeholder=""class="form-control"  />
                                            </div>
                                            
                                            <div class="form-group">
                                            </div> */}
                                            
                                            
                                      
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal" onClick={(e)=>save(val1.m_id)}  style={{width:"80px",height:"40px",backgroundColor:"blue",color:"white" }} >Update</button>
              <button type="button" class="btn btn-default" onClick={closemodel} style={{width:"60px",height:"40px",backgroundColor:"red",color:"white" }} >Close</button>
             </div>
                    </>

            )})}
            </div>
           
          </div>

        </div>
      </div>
</>
)
}export default Viewrecipe