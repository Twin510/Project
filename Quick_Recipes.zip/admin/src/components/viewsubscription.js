import React, {useState} from "react";
import Axios from "axios";
import { useEffect } from "react";  
import axios from "axios";
import { Link } from "react-router-dom";

function Viewsubscription(){ 
    
	//  const [view,setview]=useState([]);
	
	
    const [view1,setview1]=useState([]);
    const [modalID,setModalID]=useState(null);
    const [username,setusername]=useState()
    {
        useEffect(()=>{
        Axios.get('http://localhost:1334/api/getsubscription',).then((response)=>{
            setusername( response.data[0]. f_name)
            
       // alert(response.data);
        setview1(response.data);
        })
        
    },[]);
    
        
        };

  function delid(id){
   // e.preventDefault();
  alert(id);
  setModalID(id);
  }
        

      function delprod (id){
       
        Axios.post("http://localhost:1334/api/deldata",{
            mid:id
        
        }).then((response)=>{
        
        alert(response.data.msg);
       window.location="/";
        
        });
            
           
        }
      return(
<>
    <section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div  class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2>View User</h2>
                    
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">
            
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-striped m-b-0">
                                    <thead>
                                        
                                            <tr>
                                            <th data-breakpoints="xs">User Name</th>
                                            <th data-breakpoints="xs">No of Recipe</th>
                                            <th data-breakpoints="xs">Action</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                   
                                       {view1.map((val)=>{ 
                                           

                                     return(
                                       
                                        <tr>
                                           <td>{val.f_name}</td> 
                                          
                                            <td>{val.rec_count}</td>  
                                            <td>  
                                                
                                                <Link to='/userdetail' state={{f_id:val.f_id}} >View more details</Link> 
                                               
                                               
                                               </td>
                                            
                                              
                                        </tr>
                                        ) })

                                       }
                                        
                                    </tbody>
                                       
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header text-center">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                        <h1> Are  You sure want To DELETE</h1>
                       
                            <h1>{modalID}</h1>
                               <button type="button " onClick={(e)=> delprod(modalID)} style={{width:"60px",height:"40px",backgroundColor:"royalblue",color:"white" }} >Yes</button>
                               &nbsp;&nbsp;&nbsp;
                               &nbsp;
                               <button type="button " data-dismiss="modal"style={{width:"60px",height:"40px",backgroundColor:"red",color:"white" }}>NO</button>
                         
                        </div>

                    </div>
                </div>
            </div>
</>
)
}export default Viewsubscription