import React from "react";

function Aboutus(){
    return(
<div>
<div class="about" id="about">
			 <div class="about-w3lsrow"> 
				
				<div class="col-md-7 col-sm-7 w3about-img"> 
					<div class="w3about-text"> 
						<h2 class="w3l-subtitle">About Us</h2>
						<p>This application “Quick Recipes” makes finding recipes easy.
In this application, admin have rights to add recipes.The web application allows the users to find recipes based on different criteria such as chinese , Italian , and type of food.
</p>
					</div>
				</div> 
				<div class="clearfix"> </div>
			</div>
		</div>
        {/* <div class="team portfolio " id="team">
		<div class="container">
<h3 class="w3_heade_tittle_agile">Amazing Chefs</h3>
		<p class="sub_t_agileits">Meet Our Amazing Chefs...</p>
			<div class="w3layouts-grids">
					<div class="col-md-3 wthree_team_grid">
					<div class="wthree_team_grid1">
						<div class="hover14 column">
							<div>
								<figure><img src="assets/images/chef3.jpg" alt=" " class="img-responsive" /></figure>
							</div>
						</div>
						<div class="wthree_team_grid1_pos">
							<h4>Rabecca Ali</h4>
						</div>
					</div>
					<div class="wthree_team_grid2">
						<ul class="social-icons">
							 <li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3 wthree_team_grid">
					<div class="wthree_team_grid1">
						<div class="hover14 column">
							<div>
								<figure><img src="assets/images/chef4.jpg" alt=" " class="img-responsive" /></figure>
							</div>
						</div>
						<div class="wthree_team_grid1_pos">
							<h4>Rosy Carl </h4>
						</div>
					</div>
					<div class="wthree_team_grid2">
						<ul class="social-icons">
							 <li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3 wthree_team_grid">
					<div class="wthree_team_grid1">
						<div class="hover14 column">
							<div>
								<figure><img src="assets/images/chef1.jpg" alt=" " class="img-responsive" /></figure>
							</div>
						</div>
						<div class="wthree_team_grid1_pos">
							<h4>David Martin</h4>
						</div>
					</div>
					<div class="wthree_team_grid2">
						<ul class="social-icons">
						 <li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3 wthree_team_grid">
					<div class="wthree_team_grid1">
						<div class="hover14 column">
							<div>
								<figure><img src="assets/images/chef2.jpg" alt=" " class="img-responsive" /></figure>
							</div>
						</div>
						<div class="wthree_team_grid1_pos">
							<h4>Reena Scot</h4>
						</div>
					</div>
					<div class="wthree_team_grid2">
						<ul class="social-icons">
							 <li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						</ul>
					</div>
				</div>
		
				<div class="clearfix"> </div>
			</div>
		</div>
	</div> */}
</div>
)
}export default Aboutus
